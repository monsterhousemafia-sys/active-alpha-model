#!/bin/bash
cd "$(dirname "$0")"
echo "Active Alpha — Rechenleistung beitreten ..."
exec python3 worker.py
