@echo off
cd /d "%~dp0"
title Active Alpha Worker
echo Active Alpha — Rechenleistung beitreten ...
where python >nul 2>&1 && set PY=python
if not defined PY where py >nul 2>&1 && set PY=py -3
if not defined PY (
  echo Python 3 fehlt. Installiere von https://www.python.org/downloads/
  echo Haken setzen: "Add Python to PATH"
  pause
  exit / 1
)
%PY% worker.py
if errorlevel 1 pause
