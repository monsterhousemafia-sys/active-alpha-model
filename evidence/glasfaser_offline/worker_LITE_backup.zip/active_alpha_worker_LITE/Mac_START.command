#!/bin/bash
cd "$(dirname "$0")"
echo "Active Alpha — Rechenleistung beitreten ..."
if command -v python3 >/dev/null; then
  exec python3 worker.py
fi
echo "Python 3 fehlt — brew install python3 oder python.org"
read -r -p "Enter ..."
