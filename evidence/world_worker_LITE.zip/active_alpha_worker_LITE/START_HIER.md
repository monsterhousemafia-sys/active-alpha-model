# Active Alpha — In 1 Schritt beitreten

Du spendest **CPU-Leistung** — kein Geld, kein Broker.

## Start (wähle dein System)

| System | Aktion |
|--------|--------|
| **Windows** | Doppelklick auf `Windows_START.bat` |
| **macOS** | Doppelklick auf `Mac_START.command` |
| **Linux** | Doppelklick oder: `./Linux_START.sh` |

Falls Python fehlt: [python.org/downloads](https://www.python.org/downloads/) (Windows: „Add to PATH“ ankreuzen)

## Command Center

https://usa-most-myers-opponents.trycloudflare.com/

## Stoppen

Fenster schließen oder Strg+C. Fertig.

## Probleme?

Vom Worker-PC testen: `curl https://usa-most-myers-opponents.trycloudflare.com/api/health`  
**Anderes Netz?** König muss `ai_kernel spread-remote` ausführen (HTTPS-URL in ZIP).  
Details: docs/REMOTE_WORKER_DE.md
